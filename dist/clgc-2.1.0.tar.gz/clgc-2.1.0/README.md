![alt text for screen readers](https://raw.githubusercontent.com/hannaabiakl/clgc/main/logo.png "CLGC")

# CLGC

A Python package to translate First-Order Logic (FOL) into different knowledge representation languages

## Scope

A package used for handling logic statements and logic analysis using formal knowledge representation languages.

## Key Features
- Translate FOL statements to other formal Knowledge Representation (KR) languages
- Categorize syllogisms by type

## Supported KR Languages
- Common Logic Interchange Format (CLIF)
- Conceptual Graph Interchange Format (CGIF)
- Tensor Function Logic (TFL)
- Tensor Function Logic Plus (TFL+)
- CLINGO
- MINIFOLX
- PROLOG

## Setup
Start by installing the package

`pip install clgc`

Then install the dependencies

`pip install -r requirements.txt`

## Basic Usage
To load all functionalities

`from clgc.__base import *`

To create a valid syllogism in FOL, each statement of the syllogism should be followed by the `'\n'` terminator. The following example creates a syllogism of 2 premises and a conclusion:

```python
syllogism = FOLSyllogism("∀x (Bikes(x) → ¬Calledcars(x))\n ∀x (Bike(x) → Vehicle(x))\n ∃x (Vehicles(x) ∧ Bikes(x))\n")
```

To categorize syllogisms in natural language or first-order language

```python
syllogism = FOLSyllogism("∀x (Bikes(x) → ¬Calledcars(x))\n ∀x (Bike(x) → Vehicle(x))\n ∃x (Vehicles(x) ∧ Bikes(x))\n")

print
(syllogism.categorize())
# categorical
```

To translate from first-order language to another language (here, TFL+)

```python
# get syllogism as text
test_syllogism = FOLSyllogism("∀x (Bikes(x) → ¬Calledcars(x))\n ∀x (Bike(x) → Vehicle(x))\n ∃x (Vehicles(x) ∧ Bikes(x))\n").syllogism
# convert to desired logical notation - here TFL+
tfl_plus_syllogism = FOLSyllogism.fol_to_tfl_plus(test_syllogism)

print(tfl_syllogism)
# -(+B0--+C0)-(+B0-+V0)+(+V1++B1)
```

A list of functions are available to modify a syllogism:
- `add_statements` (automatically adds the given statements in that order meaning the last given statement becomes the conclusion of the syllogism)
- `add_premises` (automatically keeps the original conclusion and adds everything given as premises)
- `add_conclusion` (automatically takes the given statement as the conclusion and renders everything else to premises)

An example of adding new statements

```python
test_syllogism = FOLSyllogism("∃x (Canine(x) ∧ ¬AquaticCreatureKnownAsFish(x))\n")
        test_syllogism.add_statements(["∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))\n"])   

print(test_syllogism.statements)
# ["∃x (Canine(x) ∧ ¬AquaticCreatureKnownAsFish(x))", "∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))"])
```

An example of adding new premises

```python
test_syllogism = FOLSyllogism("∃x (Canine(x) ∧ ¬AquaticCreatureKnownAsFish(x))\n ∀x (Bike(x) → Vehicle(x))\n")
        test_syllogism.add_premises(["∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))\n"]) 

print(test_syllogism.premises)
# ["∃x (Canine(x) ∧ ¬AquaticCreatureKnownAsFish(x))", "∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))"]
```

An example of adding a new conclusion

```python
test_syllogism = FOLSyllogism("∃x (Canine(x) ∧ ¬AquaticCreatureKnownAsFish(x))\n ∀x (Bike(x) → Vehicle(x))\n")
        test_syllogism.add_conclusion("∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))\n") 

print(test_syllogism.conclusion)
# "∀x (Fish(x) → ¬MammalThereforeEveryCanineFallUnderTheCategoryOfMammal(x))"
```